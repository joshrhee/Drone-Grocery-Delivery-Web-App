const express = require('express');

// get from controller
const { createChain, createStore, createDrone, createItem, getCustomers } = require('../controllers/admin.js');

const router = express.Router();

router.post('/create_chain', createChain);
router.post('/create_store', createStore);
router.post('/create_drone', createDrone);
router.post('/create_item', createItem);
router.post('/customers', getCustomers);

module.exports = router;