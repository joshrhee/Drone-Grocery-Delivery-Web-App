const {query} = require('../services/db');

const createChain = async (req, res) => {
  res.status(500);
}

const createStore = async (req, res) => {
  res.status(500);
}

const createDrone = async (req, res) => {
  res.status(500);
}

const createItem = async (req, res) => {
  res.status(500);
}

const getCustomers = async (req, res) => {
  res.status(500);
}

module.exports = {
  createChain,
  createStore,
  createDrone,
  createItem,
  getCustomers
};