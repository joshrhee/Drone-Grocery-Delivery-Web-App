const {query} = require('../services/db');

const setCard = async (req, res) => {
  const {username, newCCNumber, newCVV, newExpDate} = req.body;
  const sql = `CALL customer_change_credit_card_information('${username}', '${newCCNumber}', ${newCVV}, ${newExpDate})`;
  console.log(sql);
  try {
    const call = await query(sql);
    console.log(call);
    return res.status(200).json({ result: call});
  } catch (error) {
    console.log(error);
    res.status(400);
    res.end();
  }
}

const getHistory = async (req, res) => {
  res.status(500);
}

const getStore = async (req, res) => {
  res.status(500);
}

const order = async (req, res) => {
  res.status(500);
}

const review = async (req, res) => {
  res.status(500);
}

const updateOrder = async (req, res) => {
  res.status(500);
}

module.exports = {
  setCard,
  getHistory,
  getStore,
  order,
  review,
  updateOrder
}