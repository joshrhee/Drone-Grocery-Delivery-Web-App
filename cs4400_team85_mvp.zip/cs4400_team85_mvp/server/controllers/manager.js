const {query} = require('../services/db');

const createItem = async (req, res) => {
  res.status(500);
}

const getDroneTechs = async (req, res) => {
  console.log("getDroneTechs started!")
  let usernameStorenameArray = []

  let finalArray = []

  const { chainname } = req.body;
  const sqlGetUsernameStorename = 
  `SELECT 
  drone_tech.Username as username,
  drone_tech.StoreName as storename
  from drone_tech
  where drone_tech.ChainName = '${chainname}'`;

  try {
    const result = await query(sqlGetUsernameStorename);
    for (let i = 0; i < result.length; i++) {
      usernameStorenameArray.push(result[i]);
    }
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "First getDroneTechs has some error"});
    res.end();
  }
  console.log("usernameStorenameArray is: ", usernameStorenameArray);

  try {
    let result = [];
    for (let i = 0; i < usernameStorenameArray.length; i++) {
      const finalSql = 
      ` SELECT DRONE_TECH.Username,
          CONCAT(FirstName, ' ', LastName) AS 'Name',
          StoreName AS Location				
        FROM USERS
          JOIN DRONE_TECH
          ON USERS.Username = DRONE_TECH.Username
        WHERE drone_tech.ChainName = '${chainname}'
        AND ('${usernameStorenameArray[i].username}' IS NULL OR USERS.Username LIKE '${usernameStorenameArray[i].username}')
        AND ('${usernameStorenameArray[i].storename}' IS NULL OR StoreName LIKE '${usernameStorenameArray[i].storename}');
      `
      result = await query(finalSql);
      finalArray.push(result);
    }
    console.log("finalArray is: ", finalArray);
    res.status(200).json({ result: finalArray})
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Second getDroneTechs has some error"});
    res.end();
  }
}


const getDrones = async (req, res) => {
  res.status(500);
}

const getStores = async (req, res) => {
  res.status(500);
}

module.exports = {
  createItem,
  getDroneTechs,
  getDrones,
  getStores
}