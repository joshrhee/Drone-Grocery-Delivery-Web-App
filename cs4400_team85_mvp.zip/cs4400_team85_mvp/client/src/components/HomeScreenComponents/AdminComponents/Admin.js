import React, {useState} from 'react';

import '../HomeScreen.css';

const Admin = (props) => {
    return(
        <div style={{
            display: 'flex', justifyContent: 'center', alignItems: 'center',
            width: '100%', height: '70vh'
        }}>
            <div>
                <form style={{display: 'flex', flexDirection: 'column'}}>
                    <br/>
                    <h1>Admin Home</h1>
                    
                    <br/>
                    <br/>
                    <div className="buttons">
                        <form style={{display: 'flex', flexDirection: 'row'}}>
                            <button className="buttons">Create Item</button>
                            <button className="buttons">Create Drone</button>
                            <button className="buttons">View Customer
                                <br/>Info</button>
                        </form>  
                        
                    </div>

                    <br/>
                    <div className="buttons">
                    <form style={{display: 'flex', flexDirection: 'row'}}>
                            <button className="buttons">Create Grocery
                                <br/>Chain</button>
                            <button className="buttons">Create Store</button>
                        </form>  
                    </div>
                </form>
            </div>
        </div>
        
    )
}

export default Admin;