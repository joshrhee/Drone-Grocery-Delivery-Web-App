import React from 'react'

const ViewOrderHistory = (props) => {
    return (
        <div>
            <div>
                <h1>Customer View Order History</h1>
            </div>
            <div>
                <button onClick={() => {props.history.goBack()}}>Back</button>
            </div>
        </div>
    )
}

export default ViewOrderHistory;