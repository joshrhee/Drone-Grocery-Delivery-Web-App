import React, {useState} from 'react'

const ChangeCCInfo = (props) => {

    let [userName, setUserName] = useState(""); //This state will save Username information
    let [firstName, setFirstName] = useState(""); //This state will save Password information
    let [lastName, setLastName] = useState(""); //This state will save Username information
    let [creditCardNumber, setCCNumber] = useState(""); //This state will save Username information
    let [securityCode, setSecurityCode] = useState(""); //This state will save Username information
    let [expDate, setExpDate] = useState(""); //This state will save Username information

    const userNameHandler = (e) => {setUserName(e.currentTarget.value)};
    const firstNameHandler = (e) => {setFirstName(e.currentTarget.value)};
    const lastNameHandler = (e) => {setLastName(e.currentTarget.value)};
    const ccNumberHandler = (e) => {setCCNumber(e.currentTarget.value)};
    const securityCodeHandler = (e) => {setSecurityCode(e.currentTarget.value)};
    const expDateHandler = (e) => {setExpDate(e.currentTarget.value)};


    return (
        <div>
            <div>
                <h1>Change Credit Card Information</h1>
            </div>
            <br/>
            <div>
                <h5>Username: <input type="text" value={userName} onChange={userNameHandler}/></h5>
                <h5>First Name: <input type="text" value={firstName} onChange={firstNameHandler}/></h5>
                <h5>Last Name: <input type="text" value={lastName} onChange={lastNameHandler}/></h5>
                <h5>New Credit Card Number: <input type="text" value={creditCardNumber} onChange={ccNumberHandler}/></h5>
                <h5>CVV: <input type="text" value={securityCode} onChange={securityCodeHandler}/></h5>
                <h5>Expiration Date: <input type="date" value={expDate} onChange={expDateHandler}/></h5>
            </div>
            <br/>
            <div>
                <button>Approve</button>
            </div>
            <div>
                <button onClick={() => {props.history.goBack()}}>Back</button>
            </div>
        </div>
    )
}

export default ChangeCCInfo;