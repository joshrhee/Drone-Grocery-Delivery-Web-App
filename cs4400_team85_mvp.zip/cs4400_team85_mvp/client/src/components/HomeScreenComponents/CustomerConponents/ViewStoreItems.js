import React from 'react'

const ViewStoreItems = (props) => {
    return (
        <div>
            <div>
                <h1>Customer View Store Items</h1>
            </div>
            <div>
                <button onClick={() => {props.history.goBack()}}>Back</button>
            </div>
        </div>
    )
}

export default ViewStoreItems;