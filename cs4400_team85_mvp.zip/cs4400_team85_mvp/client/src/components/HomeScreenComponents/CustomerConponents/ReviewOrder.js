import React from 'react'

const ReviewOrder = (props) => {
    return (
        <div>
            <div>
                <h1>Customer Review Order</h1>
            </div>
            <div>
                <button onClick={() => {props.history.goBack()}}>Back</button>
            </div>
        </div>
    )
}

export default ReviewOrder;