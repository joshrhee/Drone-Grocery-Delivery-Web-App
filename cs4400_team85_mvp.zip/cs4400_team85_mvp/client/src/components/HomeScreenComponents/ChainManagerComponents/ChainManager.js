import React, {useState} from 'react';
import {Link} from 'react-router-dom';

import './ChainManager.css';

const ChainManager = (props) => {

    return(
        <div style={{
            display: 'flex', justifyContent: 'center', alignItems: 'center',
            width: '100%', height: '70vh'
        }}>
            <div>
                <form style={{display: 'flex', flexDirection: 'column'}}>
                    <br/>
                    <h1>Chain Manager Home</h1>
                    
                    <br/>
                    <br/>
                    <div className="buttons">
                        <form style={{display: 'flex', flexDirection: 'row'}}>

                                <button id="ViewDroneTech" className="buttons" onClick={() => {props.history.push("/manager/drone_techs")}}>View Drone
                                <br/>Technicians</button>
                            
                                <button id="ViewDrones" className="buttons" onClick={() => {props.history.push("/manager/drones")}}>View Drones</button>
                        </form>  
                        
                    </div>

                    <br/>
                    <div className="buttons">
                        <form style={{display: 'flex', flexDirection: 'row'}}>
                                <button id="ChainItem" className="buttons" onClick={() => {props.history.push("/manager/create_item")}}>Create
                                <br/>Chain Item</button>
                            
                                <button id="manageStores" className="buttons" onClick={() => {props.history.push("/manager/stores")}}>Manage Stores</button>
                            
                        </form>  
                    </div>
                </form>
            </div>
        </div>
    )
}

export default ChainManager;