import React, {useState, useEffect} from 'react';
import store from '../../../../redux/store.js';
import {CHAIN_NAME} from '../../../../redux/subscribers/type.js';
import * as api from '../../../../api';


import '../ChainManager.css';


const ViewDroneTech = (props) => {

    let [chainName, setChainName] = useState(store.getState().userInfoReducer.ChainName);
    let [table, setTable] = useState();

    const getDroneTechsInfo = (e) => {
        
        //Request to get this chain's all drone_tech's info
        console.log("Starting to request to server! ");

        //Needs to work this!!!!!!!!
        api.getDroneTechs({
            chainname: chainName,
        })
        .then((results)=>{
            console.log("getDroneTech: succeed to get data ")
            console.log("result is ", results.data);

            setTable(results.data.result); //Infinite loop...

        })
        .catch((error)=>{
            console.log("Fail to get data...");
            console.log(error);
        })
    }


    return(
        <div className="ViewDroneTech" style={{
            display: 'flex', justifyContent: 'center', alignItems: 'center',
            width: '100%', height: '70vh'
        }}>
            {getDroneTechsInfo()}
            <form style={{display: 'flex', flexDirection: 'column'}}>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <h1>Chain Manager View Drone Technicians</h1>
            
                <br/>
                <form style={{display: 'flex', flexDirection: 'row'}}>
                    <h3>Chain:</h3>
                    <input placeholder={store.getState().userInfoReducer.ChainName}></input>

                    {/* Make local username state 
                    When Filter button clicked, Just show username's info
                     */}
                    <h3>Username:</h3> 
                    <input ></input>
                </form>

                <form style={{display: 'flex', flexDirection: 'row'}}>
                    <h3>Location:</h3>

                    {/* get the input Username's Chain
                    post this chain to server 
                    Loop STORE table and make an array with same chain name. If duplicate, do not incldue in the array
                    server return the array
                    loop the array's element and adding in this select*/}
                    <select>

                    </select>

                    {/* When Filter clicked, Change to show just only current state's username's info
                    Update the bottom view */}
                    <button className="buttons" >Filter</button>
                </form>

                <br/>
                <ViewInfo table={table}/>

                <br/>
                <form style={{display: 'flex', flexDirection: 'row'}}>

                    <button className="backButton" onClick={() => {props.history.push("/manager")}}>Back</button>
                    <button className="buttons">Reset</button>
                    <button className="buttons">Save</button>

                </form>
            </form>
            
        </div>
    )
}


const ViewInfo = ({table}) => {

    useEffect(() => {
        console.log(table);
    }, [table])

    return(
        <div className="table-wrapper-scroll-y my-custom-scrollbar" >
            {!table ? <h3>Press Filter to See Drones</h3> :
            <table className="table table-bordered table-striped mb-0">
            <thead>
                <tr>
                <th scope="col">Username</th>
                <th scope="col">Name</th>
                <th scope="col">Location</th>
                </tr>
            </thead>
            <tbody>
                {
                    table.map((e) => {
                        return (
                            <tr>
                                <td>{e.Username}</td>
                                <td>{e.Name}</td>
                                <td>{e.Location}</td>
                            </tr>
                        )
                    })
                }
            </tbody>
            </table>

            }
        </div>
    )
}



export default ViewDroneTech;