import React, {useState} from 'react';
import store from '../../../../redux/store.js';

const CreateChainItem = () => {
    return(
        <div style={{
            display: 'flex', justifyContent: 'center', alignItems: 'center',
            width: '100%', height: '70vh'
        }}>
            <h1>Chain Manager Create Chain Item</h1>
        
            <br/>
            <form style={{display: 'flex', flexDirection: 'row'}}>
                <h3>Chain:</h3>
                <input value={store.getState().userInfoReducer.ChainName}></input>
            </form>
        </div>
    )
}

export default CreateChainItem;