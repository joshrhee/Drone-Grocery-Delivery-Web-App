/**
 * Screen 17: View Store Orders
 * Drone Technician View Store Orders
 */
import React, {useState, useEffect} from 'react'
import store from '../../../redux/store';
import * as api from '../../../api';

const ViewStoreOrders = (props) => {

  let [startDate, setStartDate] = useState();
  let [endDate, setEndDate] = useState();
  let [table, setTable] = useState();
  let [row, setRow] = useState();
  // states for selected order, droneid, orderstatus, orderid
  const username = store.getState().userInfoReducer.Username;

  const handleSelectRow = (row) => {
    console.log(row);
    setRow(row);
  }

  const handleReset = () => {
    setStartDate();
    setEndDate();
    setRow();
    handleFilter().then((result) => {
      setTable(result.data[0]);
    }).catch((error) => {
      console.log(error);
    });
  }

  const handleFilter = async () => {
    startDate = !startDate || startDate === 'NULL' ? 'NULL' : `'${startDate}'`;
    endDate = !endDate || endDate === 'NULL' ? 'NULL' : `'${endDate}`;
    console.log(`${username}, ${startDate}, ${endDate}`);
    return api.techGetHistory({
      username: username,
      startDate: startDate,
      endDate: endDate
    })
  }

  const handleSave = () => {
    api.assignDrone({
      username: username,
      droneid: row.DroneID,
      orderStatus: row.OrderStatus,
      orderid: row.ID
    })
    .then(() => {
      console.log("Success posting data!");
      handleReset();
    }).catch((error) => {
      console.log("Failed to post data");
      console.log(error);
    });
  }

  const getOrderDetails = async () => {
    return api.getOrderDetails({
      username: username,
      orderid: row.ID
    })
    
  }

  const getOrderItems = async () => {
    return api.getOrderItems({
      username: username,
      orderid: row.ID
    })
  }


  return (
    <div style={{
      display: 'flex', justifyContent: 'center', alignItems: 'center',
      width: '100%', height: '80vh'
    }}>
      <div>
        <br />
        <div>
          <h1>View Store Orders</h1>
        </div>
        <br/>
        <div>
          <h3>Date Range: </h3>
          <div style={{
            display: 'flex', flexDirection:'row', justifyContent: 'center'
          }}>
            <input placeholder={startDate} type="date" onChange={(e) => {
            setStartDate(e.currentTarget.value)
            }}></input>
            <text> ---- </text>
          <input placeholder={endDate} type="date" onChange={(e) => {
            setEndDate(e.currentTarget.value)
            }}></input>
          </div>
          
        </div>
        <br/>
        <div>
          <ViewInfo table={table} onSelectRow={handleSelectRow}/>
        </div>
        <br/>
        <div style={{display: 'flex', flexDirection: 'row'}}>
          <button className="backButton" onClick={() => {props.history.goBack()}}>Back</button>
          <button className="buttons" onClick={() => {handleReset()}}>Reset</button>
          <button className="buttons" onClick={() => {
            handleFilter()
            .then((results) => {
              setTable(results.data.results);
              console.log(table);
              }).catch((error) => {
                console.log(error);
                console.log("Failed to get data")
              })
              }}>Filter</button>
          <button className="buttons" onClick={() => {
            let orderDetails;
            let orderItems;
            Promise.all([getOrderDetails(), getOrderItems()])
            .then((results) => {
              orderDetails = results[0].data.result;
              orderItems = results[1].data.result;
              console.log(results);
              props.history.push({
                pathname:"/drone_tech/view_order_details",
                state: {orderDetails: orderDetails, orderItems: orderItems}
            })}).catch((error) => {
              console.log("failed to get data");
              console.log(error);
            })
          }} > View Order Details</button>
          <button className="buttons" onClick={() => {handleSave()}}>Save</button>
        </div>
      </div>
    </div>
  )
}

const ViewInfo = ({ table, onSelectRow}) => {

  const handleSelectRow = (row) => {
    onSelectRow(row);
  }

  useEffect(() =>  {
    console.log(table);
  }, [table])
  return(
    <div className="table-wrapper-scroll-y my-custom-scrollbar" >
      
      {!table ? <h3> Press Filter to Retrieve Order Information</h3>
      : 
      <table className="table table-bordered table-striped mb-0">
      <thead>
          <tr>
          <th scope="col"></th>
          <th scope="col">Order ID</th>
          <th scope="col">Operator Name</th>
          <th scope="col">Order Date</th>
          <th scope="col">Drone ID</th>
          <th scope="col">Order Status</th>
          <th scope="col">Total</th>
          </tr>
      </thead>
      <tbody>
        {
          table.map((element) => {
            return <tr>
              <td><input type="radio" name="selected" onClick={() => {handleSelectRow(element)}}></input></td>
              <td>{element.ID}</td>
              <td>{element.Operator}</td>
              <td>{element.OrderDate}</td>
              <td>{element.DroneID}</td>
              <td>{element.Status}</td>
              <td>{element.Total}</td>
            </tr>
          })
        }
      </tbody>
      </table>}

    </div>
  )
}

export default ViewStoreOrders
