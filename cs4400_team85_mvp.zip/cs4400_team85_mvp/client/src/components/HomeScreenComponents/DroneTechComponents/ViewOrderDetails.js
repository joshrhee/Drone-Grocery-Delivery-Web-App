import React, {useEffect} from 'react';

const ViewOrderDetails = (props) => {

  const orderDetails = props.location.state.orderDetails[0];
  const orderItems = props.location.state.orderItems

  useEffect(() => {
    console.log(orderDetails);
    console.log(orderItems);
  }, []);
 
  return (
    <div style={{
      display: 'flex', justifyContent: 'center', alignItems: 'center',
      width: '100%', height: '70vh'
    }}>
      <div>
        <div>
          <h1>View Order Details</h1>
        </div>
        <br />
        <div style={{
          display: 'flex', justifyContent: 'flex-start', alignItems: 'flex-start', flexDirection: 'row'
        }}>
          {/* make into a grid if possible */}
          <div style={{
            display: 'flex', justifyContent: 'flex-start', alignItems: 'flex-start', flexDirection: 'column'
          }}>
            <h5>Customer Name: </h5>
            <h5>Order ID: </h5>
            <h5>Total Amount: </h5>
            <h5>Total Items: </h5>
            <h5>Date of Purchase: </h5>
            <h5>Drone ID: </h5>
            <h5>Store Associate: </h5> 
            <h5>Order Status: </h5>
            <h5>Address: </h5>
          </div>

          <div style={{
            display: 'flex', justifyContent: 'flex-start', alignItems: 'flex-start', flexDirection: 'column'
          }}>
            <input readOnly={true} value={orderDetails.Customer_Name}></input>
            <input readOnly={true} value={orderDetails.Order_ID}></input>
            <input readOnly={true} value={orderDetails.Total_Amount}></input>
            <input readOnly={true} value={orderDetails.Total_Items}></input>
            <input readOnly={true} value={orderDetails.Date_of_Purchase}></input>
            <input readOnly={true} value={orderDetails.Drone_ID}></input>
            <input readOnly={true} value={orderDetails.Store_Associate}></input>
            <input readOnly={true} value={orderDetails.Order_Status}></input>
            <input readOnly={true} value={orderDetails.Address}></input>
          </div>
        </div>
        <br/>
        <div style={{display: 'flex', flexDirection: 'row'}}>
          <button className="buttons" onClick={() => {props.history.goBack()}}>Back</button>
        </div>
      </div>
    </div>
  )
}

export default ViewOrderDetails
