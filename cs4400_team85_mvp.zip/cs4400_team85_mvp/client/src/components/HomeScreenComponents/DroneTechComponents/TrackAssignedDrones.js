import React, {useState} from 'react';
import store from '../../../redux/store.js';
import * as api from '../../../api';


const TrackAssignedDrones = (props) => {
  let [droneid, setDroneid] = useState();
  let [status, setStatus] = useState();
  let [table, setTable] = useState();
  const username = store.getState().userInfoReducer.Username;

  const handleReset = () => {
    setStatus();
    setDroneid();
    console.log(`${username}, ${status}, ${droneid}`);
    handleFilter();
  };

  const handleFilter = () => {

    status = !status ? 'All' : status;
    droneid = !droneid ? 'NULL' : droneid;
    console.log(`${username}, ${status}, ${droneid}`);
    api.techGetDrones({
      username: username,
      droneid: droneid,
      status: status
    })
    .then((results) => {
      console.log(results);
      setTable(results.data.result);
    }).catch((error) => {
      console.log("Failed to get data...");
      console.log(error);
   });
  };

  return (
    <div style={{
      display: 'flex', justifyContent: 'center', alignItems: 'center',
      width: '100%', height: '70vh'
    }}>
    <div>
      <div>
        <br />
        <h1>Track Assigned Drones</h1>
        <br />
        <div style={{display: 'flex', flexDirection: 'row'}}>
          <h3>Drone ID:  </h3>
          <input placeholder={droneid} onChange={(e) => setDroneid(e.target.value)}></input>

          
          <h3>Status:  </h3> 
          <select onChange={(e) => setStatus(e.target.value)} defaultValue={''}>
            <option></option>
            <option>Available</option>
            <option>Busy</option>
          </select>
        </div>
      </div>
      <br/>
      <ViewInfo table={table}/>
      <br/>
      <div style={{display: 'flex', flexDirection: 'row'}}>
        <button className="backButton" onClick={() => {props.history.goBack()}}>Back</button>
        <button className="buttons" onClick={() => {handleReset()}}>Reset</button>
        <button className="buttons" onClick={() => {handleFilter()}}>Filter</button>
      </div>
    </div>
    {console.log("Track Assigned Drones Initial State is: ")}
  
    </div>
  )
}

const ViewInfo = ({table}) => {
  return(
    <div className="table-wrapper-scroll-y my-custom-scrollbar" >
      {!table ? <h3>Press Filter to See Drones</h3> :
      <table className="table table-bordered table-striped mb-0">
      <thead>
          <tr>
          <th scope="col">Drone ID</th>
          <th scope="col">Drone Status</th>
          <th scope="col">Radius</th>
          </tr>
      </thead>
      <tbody>
        {
          table.map((element) => {
            return <tr>
              <td>{element.Drone_ID}</td>
              <td>{element.DroneStatus}</td>
              <td>{element.Radius}</td>
            </tr>
          })
        }
      </tbody>
      </table>
      }

    </div>
  )
}

export default TrackAssignedDrones;
