export const FIRST_NAME = 'firstName';
export const STREET = 'street';
export const LAST_NAME = 'lastName';
export const CITY = 'city';
export const USER_NAME = 'username';
export const STATE = 'state';
export const PASSWORD = 'password';
export const ZIP = 'zip';
export const CONFIRM = 'confirm';
export const CARD_NUMBER = 'cardNumber';
export const CVV = 'cvv';
export const EXP = 'expDate';
export const CHAIN_NAME = 'chainName';
export const STORE_NAME = 'storeName'


