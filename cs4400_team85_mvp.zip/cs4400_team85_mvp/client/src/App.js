import React from 'react';
import { Route, Switch, useRoutes } from 'react-router-dom';
import {Provider} from 'react-redux';


import LoginPage from './components/LoginComponents/Login.js';
import RegisterPage from './components/RegisterComponents/RegisterScreen.js';
import store from './redux/store.js';

import Admin from './components/HomeScreenComponents/AdminComponents/Admin.js'
import Customer from './components/HomeScreenComponents/CustomerConponents/Customer.js'
import ChainManager from './components/HomeScreenComponents/ChainManagerComponents/ChainManager.js'
import DroneTech from './components/HomeScreenComponents/DroneTechComponents/DroneTech.js'

//ChainManager's componenets
import ViewDroneTech from './components/HomeScreenComponents/ChainManagerComponents/ChainManagerComponents/ViewDroneTech.js';
import ViewDrones from './components/HomeScreenComponents/ChainManagerComponents/ChainManagerComponents/ViewDrones.js';
import CreateChainItem from './components/HomeScreenComponents/ChainManagerComponents/ChainManagerComponents/CreateChainItem.js';
import ManageStores from './components/HomeScreenComponents/ChainManagerComponents/ChainManagerComponents/ManageStores.js';

//DroneTech's components
import ViewStoreOrders from './components/HomeScreenComponents/DroneTechComponents/ViewStoreOrders';
import ViewOrderDetails from './components/HomeScreenComponents/DroneTechComponents/ViewOrderDetails';
import TrackAssignedDrones from './components/HomeScreenComponents/DroneTechComponents/TrackAssignedDrones';

//Customer's components
import ChangeCCInfo from "./components/HomeScreenComponents/CustomerConponents/ChangeCCInfo";
import ReviewOrder from "./components/HomeScreenComponents/CustomerConponents/ReviewOrder";
import ViewOrderHistory from "./components/HomeScreenComponents/CustomerConponents/ViewOrderHistory";
import ViewStoreItems from "./components/HomeScreenComponents/CustomerConponents/ViewStoreItems";

import './App.css';

function App() {
  return (

    <Provider store={store}>
        <div className="App">
            <Switch>
              {/* Login Screen */}
              <Route exact path="/" component={LoginPage}/>
              {/* Register Screen */}
              <Route exact path="/register" component={RegisterPage}/>
              {/* Admin Home */}
              <Route exact path="/admin" component={Admin}/>
              {/* Customer Home */}
              <Route exact path="/customer" component={Customer}/>
              <Route exact path="/customer/change_cc_info" component={ChangeCCInfo}/>
              <Route exact path="/customer/review_order" component={ReviewOrder}/>
              <Route exact path="/customer/view_order_history" component={ViewOrderHistory}/>
              <Route exact path="/customer/view_store_items" component={ViewStoreItems}/>
              {/* Chain Manager Home */}
              <Route exact path="/manager" component={ChainManager}/>
              <Route exact path="/manager/drone_techs" component={ViewDroneTech}/>
              <Route exact path="/manager/drones" component={ViewDrones}/>
              <Route exact path="/manager/create_item" component={CreateChainItem}/>
              <Route exact path="/manager/stores" component={ManageStores}/>
              {/* Drone Tech Home */}
              <Route exact path="/drone_tech" component={DroneTech}/>
              <Route exact path="/drone_tech/view_store_orders" component={ViewStoreOrders} />
              <Route exact path="/drone_tech/view_order_details" component={ViewOrderDetails} />
              <Route exact path="/drone_tech/track_assigned_drones" component={TrackAssignedDrones} />
            </Switch>
        </div>
    </Provider>

  );
}

export default App;
